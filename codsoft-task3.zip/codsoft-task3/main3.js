
let input=document.getElementById('input');
let btns=document.querySelectorAll('button');

let s=" ";
let a=Array.from(btns);
a.forEach(button=>{
    button.addEventListener('click',(e)=>{
        if(e.target.innerHTML=='='){
            s=eval(s);
            input.value=s;
        }
        else if(e.target.innerHTML=='C')
        {
            s=" ";
            input.value=s;
        }
        else if(e.target.innerHTML=='X')
        {
            s=s.substring(0,s.length-1);
            input.value=s;
        }
        else
        {
            s += e.target.innerHTML;
            input.value=s;
        }
    })
})